=============================
nsxsdk
=============================

.. image:: https://badge.fury.io/py/nsxsdk.png
    :target: http://badge.fury.io/py/nsxsdk

.. image:: https://travis-ci.org/rvichery/nsxsdk.png?branch=master
    :target: https://travis-ci.org/rvichery/nsxsdk

.. image:: https://pypip.in/d/nsxsdk/badge.png
    :target: https://pypi.python.org/pypi/nsxsdk


NSX for vSphere SDK


Features
--------

* TODO

