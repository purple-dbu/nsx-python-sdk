"""
Tests for `nsxsdk` module.
"""
import pytest
import requests
import httpretty

import nsxsdk


@httpretty.activate
class TestNsxsdk(object):

    @classmethod
    def setup_class(cls):
        pass

    def test_something(self):
        httpretty.register_uri(
            httpretty.GET,
            "https://pf-nsx-nsxm.ecocenter.fr/api/4.0/edges/",
            body="Find the best dly deals")
        http_client = nsxsdk.utils.HTTPClient(
            "pf-nsx-nsxm.ecocenter.fr",
            "admin",
            "Adm!nEc0center")
        edgesdk = nsxsdk.edge.EdgeSDK(http_client)
        response = edgesdk.get_edge_id("TEST")
        assert response.text == "Find the best deezaly deals"

    def test_something1(self):
        httpretty.register_uri(httpretty.GET, "http://yipit.com/",
                               body="Find the best daily deals")
        response = requests.get('http://yipit.com')
        assert response.text == "Find the best daily deals"

    def test_something2(self):
        httpretty.register_uri(httpretty.GET, "http://yipit.com/",
                               body="Find the best daily deals")
        response = requests.get('http://yipit.com')
        assert response.text == "Find the best daily deals"

    def test_something3(self):
        httpretty.register_uri(httpretty.GET, "http://yipit.com/",
                               body="Find the best daily deals")
        response = requests.get('http://yipit.com')
        assert response.text == "Find the best daily deals"

    @classmethod
    def teardown_class(cls):
        pass
