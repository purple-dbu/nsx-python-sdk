=============================
NSX for vSphere Python SDK
=============================

.. image:: https://badge.fury.io/py/nsx-python-sdk.png
    :target: http://badge.fury.io/py/nsx-python-sdk

.. image:: https://travis-ci.org/rvichery/nsx-python-sdk.png?branch=dev
    :target: https://travis-ci.org/rvichery/nsx-python-sdk

.. image:: https://pypip.in/d/nsx-python-sdk/badge.png
    :target: https://pypi.python.org/pypi/nsx-python-sdk


Features
--------

* TODO

